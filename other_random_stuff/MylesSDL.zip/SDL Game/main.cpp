// CREATOR: MYLES BUSIG
// NO TOUCHY!!!

#include "kit.h"

// Function declorations
extern void Initalize(bool debugWindow, const char * gameName = "Unknown Game, v0.0", bool fullscreen = false, int w = 600, int h = 400, int r = 200, int g = 200, int b = 200, int a = 255);
extern void Update();
extern void Render();

// Weather or not the game is currently running (NOT PAUSED, RUNNING)
bool Running = false;

// Window where the game takes place
SDL_Window * Window;
// Renderer to display the objects
SDL_Renderer * Renderer;

int main(int argc, char * argv[])
{
	// Initalize game
	Initalize(true, "SDL Game, v0.0");

	// Update game
	while (Running)
	{
		Update();
	}

	// Destroy the renderer
	SDL_DestroyRenderer(Renderer);
	// Destroy the window
	SDL_DestroyWindow(Window);
	// Quit the game
	SDL_Quit();

	return 0;
}

// Function used to initalize the game
void Initalize(bool debugWindow, const char * gameName, bool fullscreen, int w, int h, int r, int g, int b, int a)
{
	cout << "Initalizing game \"" << gameName << "\"..." << endl;

	// Number of errors encountered while initalizing game
	int initErrors = 0;

	// Print debug stuff
	if (debugWindow)
	{
		cout << endl;
		cout << "----- WINDOW DEBUG -----" << endl;
		cout << "Gamename: " << gameName << endl;
		cout << "Fullscreen: " << fullscreen << endl;
		cout << "w: " << w << endl;
		cout << "h: " << h << endl;
		cout << "r: " << r << endl;
		cout << "g: " << g << endl;
		cout << "b: " << b << endl;
		cout << "a: " << a << endl;
		cout << "------------------------" << endl;
		cout << endl;
	}

	// Set flags (fullscreen/not fullscreen)
	int flags = 0;
	if (fullscreen)
		flags = SDL_WINDOW_FULLSCREEN;

	// Enable video, audio, and the event system (included in video)
	SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);

	// Create window
	Window = SDL_CreateWindow(gameName, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h, flags);
	if (Window == NULL)
	{
		// Add window creation error
		++initErrors;
		cout << "ERROR CREATING WINDOW FOR GAME \"" << gameName << "\"!" << endl;
	}
	else
	{
		// Create renderer if window exists
		Renderer = SDL_CreateRenderer(Window, -1, 0);
		if (Renderer == NULL)
		{
			// Add renderer creation error
			++initErrors;
			cout << "ERROR CREATING RENDERER FOR GAME \"" << gameName << "\"!" << endl;
		}
		else
		{
			// Set renderer draw color if the renderer exists
			Running = true;
			SDL_SetRenderDrawColor(Renderer, r, g, b, a);
		}
	}

	cout << "Finished initalizing game \"" << gameName << "\" with '" << initErrors << "' error(s)" << endl;
}

// Function used to update the game (called every frame)
void Update()
{
	// Update objects

	// Handle queued events in a loop
	SDL_Event currentEvent;
	while (SDL_PollEvent(&currentEvent))
	{
		switch (currentEvent.type) {
		case SDL_MOUSEMOTION:
			cout << "MouseMove { " << currentEvent.motion.x << ", " << currentEvent.motion.y << " }" << endl;
			break;
		default:
			cout << "UnhandledEvent { \"" << currentEvent.common.type << currentEvent.common.timestamp << "\" }" << endl;
		}
	}

	// Useful functions you might want to look into
	//SDL_AddEventWatch
	//SDL_BUTTON... [This is actually a group of macros, not functions]
	//SDL_Delay
	//SDL_DelEventWatch
	//SDL_EventState
	//SDL_FilterEvents
	//SDL_FlushEvent
	//SDL_FlushEvents
	//SDL_GameControllerAddMapping
	//SDL_GameControllerClose
	//SDL_GameControllerEventState
	//SDL_GameControllerFromInstanceID
	//SDL_GameControllerGetAttached
	//SDL_GameControllerGetAxis
	//SDL_GameControllerGetAxisFromString
	//SDL_GameControllerGetButton
	//SDL_GameControllerGetButtonFromString
	//SDL_GameControllerGetJoystick
	//SDL_GameControllerGetStringForAxis
	//SDL_GameControllerGetStringForButton
	//SDL_GameControllerOpen
	//SDL_GameControllerUpdate [Called automatically in some cases]
	//SDL_GetBasePath
	//SDL_GetClipboardText
	//SDL_GetCursor
	//SDL_GetEventFilter
	//SDL_GetGlobalMouseState
	//SDL_GetKeyboardState
	//SDL_GetKeyFromName
	//SDL_GetKeyFromScancode
	//SDL_GetKeyName
	//SDL_GetModState
	//SDL_GetMouseState
	//SDL_GetPrefPath
	//SDL_GetRelativeMouseState
	//SDL_GetScancodeFromKey
	//SDL_GetScancodeFromName
	//SDL_GetScancodeName
	//SDL_GetTicks
	//SDL_HasClipboardText
	//SDL_HasEvent
	//SDL_HasEvents
	//SDL_PeepEvents
	//SDL_PollEvent
	//SDL_PumpEvents
	//SDL_PushEvent
	//SDL_SetCursor
	//SDL_SetEventFilter
	//SDL_SetWindowBordered
	//SDL_SetWindowFullscreen
	//SDL_SetWindowsMessageHook
	//SDL_ShowCursor
	//SDL_WaitEvent
	//SDL_WaitEventTimeout

	Render();
}

// Function used to render the game (called every frame after the objects have been updated)
void Render()
{
	// Clear the renderer
	SDL_RenderClear(Renderer);

	// Render objects

	// Present the renderer (actually display the objects)
	SDL_RenderPresent(Renderer);
}