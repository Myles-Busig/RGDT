// CREATOR: MYLES BUSIG
// NO TOUCHY!!!

#pragma once
//#pragma comment(lib, "\"SDL Game/SDL Game/SDL2-2.0.8/lib/x64/SDL2.lib\"")
//#pragma comment(lib, "\"SDL Game/SDL Game/SDL2_image - 2.0.3/lib/x64/SDL2_image.lib\"")

// "std" namespace
using namespace std;

// Necessary header files
#include "SDL.h"
#include "SDL_image.h"
#include "WindowsPlus.h"
#include <iostream>